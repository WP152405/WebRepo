/**
 * 
 */
// 한줄 주석
<!-- HTML -->
alert("hello, js");